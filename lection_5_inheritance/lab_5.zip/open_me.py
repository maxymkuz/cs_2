# module lets you to examine and import all 3
# directories with modules in this assignment

# This executes my game in terminal. You can
# import student_simulator_game from any other file or path.
import student_simulator_game
