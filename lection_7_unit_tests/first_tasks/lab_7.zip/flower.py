class Flower:
    """ Represents a single flower"""
    def __init__(self, color, price, petals):
        self.color = color
        self.price = float(price)
        self.petals = int(petals)

    def __str__(self):
        """() -> str
        Returns a convenient representation
        """
        return f"The {self.color} tulip costs {self.price} and has " \
               f"{self.petals} petals"


class Tulip(Flower):
    """
    Represents a Tulip, a subclass of Flower
    """
    def __init__(self, color, price, petals):
        """
        (str, float, int) -> None
        Initializes a Tulip
        """
        super().__init__(color, price, petals)

    def __str__(self):
        """() -> str
        Returns a convenient and visual - froendly
        representation in string
        """
        return f"The {self.color} tulip costs {self.price} and has " \
               f"{self.petals} petals"


class Rose(Flower):
    """
    Represents a Rose, a subclass of Flower
    """
    def __init__(self, color, price, petals):
        """
        (str, float, int) -> None
        Initializes a Rose
        """
        super().__init__(color, price, petals)

    def __str__(self):
        """() -> str
        Returns a convenient and visual - froendly
        representation in string
        """
        return f"The {self.color} rose costs {self.price} and has " \
               f"{self.petals} petals"


class Chamomile(Flower):
    """
    Represents a Chamomile, a subclass of Flower
    """
    def __init__(self, color, price, petals):
        """
        (str, float, int) -> None
        Initializes a Chamomile
        """
        super().__init__(color, price, petals)

    def __str__(self):
        """() -> str
        Returns a convenient and visual - froendly
        representation in string
        """
        return f"The {self.color} chamomile costs {self.price} and has " \
               f"{self.petals} petals"


class FlowerSet:
    """
    Represents a single set of flowers -- of a single type
    of flowers
    """
    def __init__(self, flower, count):
        """
        (Flower, int) -> None
        Initializes a single flower set
        """
        self.flower = flower
        self.count = count

    def price(self):
        """
        () -> float
        Returns a total price for a flower set
        """
        return self.flower.price * self.count

    def __str__(self):
        """() -> str
        Returns a convenient and visual - friendly
        representation in string
        """
        return f"The set of {self.count} {self.flower.color} " \
               f"costs {self.price()}"


class Bucket:
    """
    Represents a bucket of flowers, which has a list of
    sets of Flowers as attribute
    """
    def __init__(self, flowerSets):
        """
        (Flower, int) -> None
        Initializes a single Bucket
        """
        self.flowers = flowerSets

    def price(self):
        """
        () -> float
        Returns a total price for a flower set
        """
        return float(sum([i.flower.price * i.count for i in self.flowers]))

    def __str__(self):
        """() -> str
        Returns a convenient and visual - friendly
        representation in string
        """
        return f"The bucket of {sum([i.count for i in self.flowers])} flowers " \
               f"and 5 yellow tulips costs {self.price()}"
